"""
This is my favorite song
"""
song ="playlist" #Song's name
Artist="Jonas Monar"#Singer's name from Germany
TimeMinutes = 3#Song's Duration

"""
Print Variables
"""

print(song)
print(Artist)
print(TimeMinutes)
