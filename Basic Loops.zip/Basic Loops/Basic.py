
for number in range(100):
     if number%5 == 0 and number%3 == 0:
      print (number)
      print ("BuzzFizz")

      continue
     if number%5 == 0:
      print (number)
      print ("Buzz")

for number in range(100):
     if number%3 == 0:
      print (number)
      print ("Fizz")

