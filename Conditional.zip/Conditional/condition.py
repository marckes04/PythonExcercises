def fun(a, b, c):
     if a == b and c == b:
          print('function is true')
     elif a!=b or a!=c or b!=c:
      print('Function is false')

fun(2,2,2)
