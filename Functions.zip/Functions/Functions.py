def Artist(name):
  print(name)

Artist("David Grun")


def Genre(name):
  print(name)

Genre("Pop")



def Year(name):
  print(name)

Year("1995")
